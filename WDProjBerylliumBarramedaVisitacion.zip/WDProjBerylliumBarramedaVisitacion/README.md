
Website Title
Title: Porsche Experience
Subtitle: Vehicle Showroom and Configurator

Description
  This website aims to show and display two current models in Porsche’s Lineup, being the Porsche 911 GT3RS and the Porsche 911 Turbo S. This website aims to provide clear and detailed information about these vehicles, for people who want more information about them. The website will also contain clear detailed images of these vehicles as part of its “Showroom”, and will also give links to related videos on social media about the vehicles. The website will also contain links to news outlets related to the vehicles, and a link to the actual Porsche website itself. The configurator portion will be a way to select from a given selection of options on the cars, and based on the given selection there will be an image of the car given the specifications selected by the user.

Outline
The outline for the website is contained in the wireframe.

Js incorporation
In the following quarters, we plan to incorporate javascript in our website with the use of our configurator. The user will select from a series of prompts, and based on those series of prompts, the website will produce an image of what the car will look like with the specification given by the user.

Wireframe
https://www.canva.com/design/DAGW1nBwm2U/mJVumIm5Nx4R674DUH-fuA/edit?utm_content=DAGW1nBwm2U&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton